import json,hashlib,re
from pathlib import Path
from tests.manual.v2.isolated_windows_suite import observed_ids
B=Path('build/ap-iv2-020-suite');S=B/'review-isolated-windows';raw=json.loads((S/'result.json').read_text());expected=set(raw['expectedTestIds']);rows=[];observed=set()
for row in raw['rows']:
    module=row['module'];path=S/(module+'.log');retry=module=='test_v2_settings_service'
    if retry:path=B/'review-settings-retry.log'
    text=path.read_text(encoding='utf8',errors='replace');ids=observed_ids(text)
    want={name for name in expected if name.startswith(module+'.')}
    summary=re.search(r'Ran (\d+) tests? in ',text)
    ok=re.search(r'^OK\s*$',text,re.M) and summary and int(summary[1])==len(want)
    if not retry:ok=ok and row['exitCode']==0
    assert ok and ids==want and '... skipped ' not in text,(module,len(ids),len(want))
    observed.update(ids);rows.append(dict(module=module,tests=len(ids),result='PASS',log=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),retry=retry))
assert observed==expected and len(observed)==1400
result=dict(result='PASS',tests=len(observed),skips=0,exactDiscoveredSet=True,modules=len(rows),rows=rows,
    originalAssessmentSha256=hashlib.sha256((S/'result.json').read_bytes()).hexdigest(),
    corrections='Initial assessment regex missed multiline unittest docstrings. All original unit workers exit0 except settings module; its under-load2s fake-server wait failed once and full module34tests passed in fresh serial retry. All failures/logs retained, no excluded test ID.')
(B/'review-final-windows-assessment.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
